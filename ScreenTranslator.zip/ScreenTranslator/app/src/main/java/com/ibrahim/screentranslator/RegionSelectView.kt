package com.ibrahim.screentranslator

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Full-screen drag-to-select view. Calls onDone with fractions [l, t, r, b], or null if cancelled. */
class RegionSelectView(
    context: Context,
    private val onDone: (FloatArray?) -> Unit
) : View(context) {

    private val d = resources.displayMetrics.density
    private var x0 = 0f
    private var y0 = 0f
    private var x1 = 0f
    private var y1 = 0f
    private var touched = false

    private val dim = Paint().apply { color = 0xAA000000.toInt() }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF7C4DFF.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * d
    }
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 16f * d
        textAlign = Paint.Align.CENTER
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (!touched) {
            c.drawRect(0f, 0f, w, h, dim)
        } else {
            val l = min(x0, x1)
            val r = max(x0, x1)
            val t = min(y0, y1)
            val b = max(y0, y1)
            c.drawRect(0f, 0f, w, t, dim)
            c.drawRect(0f, b, w, h, dim)
            c.drawRect(0f, t, l, b, dim)
            c.drawRect(r, t, w, b, dim)
            c.drawRect(l, t, r, b, line)
        }
        c.drawText("اسحب لتحديد المنطقة اللي تبي تترجمها", w / 2, 64f * d, hint)
        c.drawText("اضغط بدون سحب للإلغاء", w / 2, 92f * d, hint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                x0 = e.x; y0 = e.y; x1 = e.x; y1 = e.y
                touched = true
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                x1 = e.x; y1 = e.y
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                x1 = e.x; y1 = e.y
                val l = min(x0, x1)
                val r = max(x0, x1)
                val t = min(y0, y1)
                val b = max(y0, y1)
                if (r - l < 60 * d || b - t < 40 * d || width == 0 || height == 0) {
                    onDone(null)
                } else {
                    onDone(floatArrayOf(l / width, t / height, r / width, b / height))
                }
            }
        }
        return true
    }
}
