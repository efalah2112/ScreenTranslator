package com.ibrahim.screentranslator

import android.content.Context
import com.google.mlkit.nl.translate.TranslateLanguage

/** Languages the app can read (Latin-script only) and translate into. */
object Langs {
    val sources = listOf(
        "الإنجليزية" to TranslateLanguage.ENGLISH,
        "الإسبانية" to TranslateLanguage.SPANISH,
        "الفرنسية" to TranslateLanguage.FRENCH,
        "الألمانية" to TranslateLanguage.GERMAN,
        "البرتغالية" to TranslateLanguage.PORTUGUESE,
        "الإيطالية" to TranslateLanguage.ITALIAN,
        "التركية" to TranslateLanguage.TURKISH,
        "الإندونيسية" to TranslateLanguage.INDONESIAN
    )
    val targets = listOf(
        "العربية" to TranslateLanguage.ARABIC,
        "الإنجليزية" to TranslateLanguage.ENGLISH,
        "الفرنسية" to TranslateLanguage.FRENCH,
        "الإسبانية" to TranslateLanguage.SPANISH,
        "التركية" to TranslateLanguage.TURKISH,
        "الإندونيسية" to TranslateLanguage.INDONESIAN
    )
}

object Accents {
    val names = listOf("بنفسجي", "أزرق", "أخضر", "برتقالي", "وردي")
    val colors = intArrayOf(
        0xFF7C4DFF.toInt(), 0xFF2979FF.toInt(), 0xFF00C853.toInt(),
        0xFFFF9100.toInt(), 0xFFFF4081.toInt()
    )
}

class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("screen_translator", Context.MODE_PRIVATE)

    var intervalMs: Long
        get() = sp.getLong("interval", 2000L)
        set(v) = sp.edit().putLong("interval", v).apply()

    var fontScale: Float
        get() = sp.getFloat("fontScale", 1f)
        set(v) = sp.edit().putFloat("fontScale", v).apply()

    /** Opacity of the translation boxes, 30..100 (%). */
    var opacity: Int
        get() = sp.getInt("opacity", 92)
        set(v) = sp.edit().putInt("opacity", v).apply()

    var accent: Int
        get() = sp.getInt("accent", 0).coerceIn(0, Accents.colors.size - 1)
        set(v) = sp.edit().putInt("accent", v).apply()

    var srcIdx: Int
        get() = sp.getInt("src", 0).coerceIn(0, Langs.sources.size - 1)
        set(v) = sp.edit().putInt("src", v).apply()

    var tgtIdx: Int
        get() = sp.getInt("tgt", 0).coerceIn(0, Langs.targets.size - 1)
        set(v) = sp.edit().putInt("tgt", v).apply()

    /** true = scan continuously, false = only when "translate now" is tapped. */
    var auto: Boolean
        get() = sp.getBoolean("auto", true)
        set(v) = sp.edit().putBoolean("auto", v).apply()

    /** Region to translate as fractions [left, top, right, bottom] of the screen, or null = full screen. */
    fun region(): FloatArray? {
        if (!sp.getBoolean("hasRegion", false)) return null
        return floatArrayOf(
            sp.getFloat("rl", 0f), sp.getFloat("rt", 0f),
            sp.getFloat("rr", 1f), sp.getFloat("rb", 1f)
        )
    }

    fun setRegion(r: FloatArray?) {
        val e = sp.edit()
        if (r == null) {
            e.putBoolean("hasRegion", false)
        } else {
            e.putBoolean("hasRegion", true)
                .putFloat("rl", r[0]).putFloat("rt", r[1])
                .putFloat("rr", r[2]).putFloat("rb", r[3])
        }
        e.apply()
    }
}
