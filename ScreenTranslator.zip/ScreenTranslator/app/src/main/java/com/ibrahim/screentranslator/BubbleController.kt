package com.ibrahim.screentranslator

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.hypot

/** The draggable floating button and its pop-up menu. */
class BubbleController(
    private val context: Context,
    private val wm: WindowManager,
    private val prefs: Prefs,
    private val actions: Actions
) {

    interface Actions {
        fun isPaused(): Boolean
        fun togglePause()
        fun scanNow()
        fun toggleMode()
        fun selectRegion()
        fun clearRegion()
        fun fontDelta(delta: Float)
        fun openSettings()
        fun stopService()
    }

    private val d = context.resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()

    private val container = LinearLayout(context)
    private val bubble = TextView(context)
    private val panel = LinearLayout(context)

    private lateinit var pauseRow: TextView
    private lateinit var modeRow: TextView
    private lateinit var clearRegionRow: TextView

    private var expanded = false
    private var savedX = 0
    private var savedY = 0

    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    init {
        buildUi()
    }

    @Suppress("DEPRECATION")
    private fun screen(): DisplayMetrics {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return m
    }

    // ------------------------------------------------------------------ UI

    private fun buildUi() {
        container.orientation = LinearLayout.VERTICAL
        container.layoutDirection = View.LAYOUT_DIRECTION_LTR

        bubble.apply {
            text = "ع"
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
            alpha = 0.92f
        }
        setupBubbleTouch()

        panel.apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply {
                setColor(0xF21A1C26.toInt())
                cornerRadius = dp(16).toFloat()
            }
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(dp(300), LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { setMargins(0, dp(6), 0, dp(6)) }
        }

        pauseRow = cell("") { actions.togglePause() }
        val scanRow = cell("🔍   ترجم الآن") { actions.scanNow() }
        modeRow = cell("") { actions.toggleMode() }
        val regionRow = cell("▭   تحديد منطقة") { actions.selectRegion() }
        clearRegionRow = cell("⛶   الشاشة كاملة") { actions.clearRegion() }
        val settingsRow = cell("⚙   الإعدادات") { actions.openSettings() }
        val stopRow = cell("✕   إيقاف التطبيق") { actions.stopService() }

        panel.addView(pair(pauseRow, scanRow))
        panel.addView(pair(modeRow, regionRow))
        panel.addView(pair(clearRegionRow, settingsRow))

        val minus = cell("−", collapse = false) { actions.fontDelta(-0.1f) }
        val plus = cell("+", collapse = false) { actions.fontDelta(0.1f) }
        val label = TextView(context).apply {
            text = "حجم الخط"
            textSize = 13f
            setTextColor(0xFFB9BEFF.toInt())
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.4f)
        }
        panel.addView(LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(minus)
            addView(label)
            addView(plus)
        })
        panel.addView(pair(stopRow, null))

        container.addView(bubble)
        container.addView(panel)
    }

    private fun cell(text: String, collapse: Boolean = true, onClick: () -> Unit): TextView =
        TextView(context).apply {
            this.text = text
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(11), dp(8), dp(11))
            isClickable = true
            background = RippleDrawable(
                ColorStateList.valueOf(0x44FFFFFF), null, ColorDrawable(Color.WHITE)
            )
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                onClick()
                if (collapse) collapseMenu()
                refresh()
            }
        }

    private fun pair(a: View, b: View?): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a)
        if (b != null) addView(b)
    }

    private fun updateBubbleBg() {
        val c = Accents.colors[prefs.accent]
        val dark = Color.rgb(
            (Color.red(c) * 0.6f).toInt(), (Color.green(c) * 0.6f).toInt(), (Color.blue(c) * 0.6f).toInt()
        )
        bubble.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR, intArrayOf(c, dark)
        ).apply {
            shape = GradientDrawable.OVAL
            setStroke(dp(2), 0x66FFFFFF)
        }
    }

    // ------------------------------------------------------------------ touch

    private fun setupBubbleTouch() {
        val slop = ViewConfiguration.get(context).scaledTouchSlop
        bubble.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x; startY = params.y
                        touchX = e.rawX; touchY = e.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - touchX
                        val dy = e.rawY - touchY
                        if (!moved && hypot(dx, dy) > slop) {
                            moved = true
                            if (expanded) {
                                collapseMenu()
                                startX = params.x; startY = params.y
                                touchX = e.rawX; touchY = e.rawY
                                return true
                            }
                        }
                        if (moved) {
                            params.x = (startX + dx).toInt()
                            params.y = (startY + dy).toInt()
                            wm.updateViewLayout(container, params)
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) toggleMenu()
                        return true
                    }
                }
                return false
            }
        })
    }

    // ------------------------------------------------------------------ menu

    private fun toggleMenu() = if (expanded) collapseMenu() else expandMenu()

    private fun expandMenu() {
        val m = screen()
        savedX = params.x
        savedY = params.y
        panel.visibility = View.VISIBLE
        refresh()
        panel.measure(
            View.MeasureSpec.makeMeasureSpec(dp(300), View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val panelH = panel.measuredHeight + dp(12)
        val above = savedY > m.heightPixels / 2

        container.removeView(panel)
        if (above) {
            container.addView(panel, 0)
            params.y = (savedY - panelH).coerceAtLeast(0)
        } else {
            container.addView(panel)
            params.y = savedY
        }
        params.x = savedX.coerceAtMost(m.widthPixels - dp(300)).coerceAtLeast(0)
        expanded = true
        wm.updateViewLayout(container, params)
    }

    private fun collapseMenu() {
        if (!expanded) return
        panel.visibility = View.GONE
        params.x = savedX
        params.y = savedY
        expanded = false
        wm.updateViewLayout(container, params)
    }

    fun refresh() {
        pauseRow.text = if (actions.isPaused()) "▶   استئناف" else "⏸   إيقاف مؤقت"
        modeRow.text = if (prefs.auto) "🔄   الوضع: تلقائي" else "👆   الوضع: يدوي"
        clearRegionRow.visibility = if (prefs.region() != null) View.VISIBLE else View.GONE
        bubble.alpha = if (actions.isPaused()) 0.5f else 0.92f
        updateBubbleBg()
    }

    fun show() {
        val m = screen()
        params.x = m.widthPixels - dp(70)
        params.y = m.heightPixels / 3
        wm.addView(container, params)
        refresh()
    }

    fun remove() {
        runCatching { wm.removeView(container) }
    }
}
