package com.ibrahim.screentranslator

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.drawable.Icon
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class TranslatorService : Service() {

    companion object {
        const val ACTION_STOP = "com.ibrahim.screentranslator.STOP"
        const val ACTION_TOGGLE = "com.ibrahim.screentranslator.TOGGLE"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"

        private const val CHANNEL = "screen_translator"
        private const val NOTIF_ID = 1
        private const val TAG = "ScreenTranslator"

        /** How often the screen is scanned. Lower = faster but more battery/CPU. */
        const val INTERVAL_MS = 2000L

        /** How long the overlay stays hidden before taking a screenshot (so OCR sees the English text). */
        const val HIDE_DELAY_MS = 220L

        private val LATIN = Regex("[A-Za-z]{2,}")
        private val ARABIC = Regex("[\\u0600-\\u06FF]")
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var wm: WindowManager
    private var overlay: OverlayView? = null
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var capW = 0
    private var capH = 0

    private var loopJob: Job? = null
    @Volatile private var paused = false
    private var lastSignature = ""
    private val cache = HashMap<String, String>()

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.ARABIC)
            .build()
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "مترجم الشاشة", NotificationManager.IMPORTANCE_LOW)
        )
    }

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE -> {
                paused = !paused
                if (paused) {
                    lastSignature = ""
                    overlay?.setItems(emptyList(), 1, 1)
                }
                notify(if (paused) "متوقف مؤقتاً" else "الترجمة شغالة")
                return START_NOT_STICKY
            }
        }

        if (projection != null) return START_NOT_STICKY // already running

        val code = intent?.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            intent?.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null || code != Activity.RESULT_OK) {
            stopSelf()
            return START_NOT_STICKY
        }

        // Must be a foreground service BEFORE getting the projection (Android 14+).
        val n = buildNotification("جاري التحضير...")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }

        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                mainHandler.post { stopSelf() }
            }
        }, mainHandler)

        overlay = OverlayView(this).also { wm.addView(it, overlayParams()) }
        loopJob = scope.launch { runLoop() }
        return START_NOT_STICKY
    }

    private fun overlayParams() = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }

    // ---------------------------------------------------------------- main loop

    private suspend fun runLoop() {
        try {
            notify("جاري تحميل نموذج الترجمة (يحتاج إنترنت أول مرة)...")
            translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            notify("الترجمة شغالة")
        } catch (e: Exception) {
            Log.e(TAG, "model download failed", e)
            notify("فشل تحميل النموذج: ${e.message}")
            return
        }

        while (currentCoroutineContext().isActive) {
            if (!paused) {
                try {
                    cycle()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.e(TAG, "cycle failed", e)
                }
            }
            delay(INTERVAL_MS)
        }
    }

    private suspend fun cycle() {
        val bmp = captureBitmap() ?: return
        try {
            val result = recognizer.process(InputImage.fromBitmap(bmp, 0)).await()

            val blocks = result.textBlocks.mapNotNull { b ->
                val box = b.boundingBox ?: return@mapNotNull null
                val text = b.text.replace('\n', ' ').trim()
                if (text.length > 400 || !LATIN.containsMatchIn(text) || ARABIC.containsMatchIn(text)) {
                    null
                } else {
                    text to box
                }
            }

            val signature = blocks.joinToString("|") { (t, r) -> "$t@${r.left / 24},${r.top / 24}" }
            if (signature == lastSignature) return
            lastSignature = signature

            if (cache.size > 2000) cache.clear()
            val items = blocks.map { (text, box) ->
                val ar = cache[text] ?: translator.translate(text).await().also { cache[text] = it }
                OverlayView.Item(box, ar)
            }

            withContext(Dispatchers.Main) { overlay?.setItems(items, bmp.width, bmp.height) }
        } finally {
            bmp.recycle()
        }
    }

    // ---------------------------------------------------------------- capture

    @Suppress("DEPRECATION")
    private fun ensureCapture() {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        val w = dm.widthPixels
        val h = dm.heightPixels
        if (virtualDisplay != null && w == capW && h == capH) return

        val oldReader = imageReader
        val newReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        val vd = virtualDisplay
        if (vd == null) {
            // Android 14+: a projection token can create only ONE virtual display, so reuse it afterwards.
            virtualDisplay = projection?.createVirtualDisplay(
                "ScreenTranslator", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                newReader.surface, null, null
            )
        } else {
            vd.resize(w, h, dm.densityDpi)
            vd.surface = newReader.surface
        }
        imageReader = newReader
        oldReader?.close()
        capW = w
        capH = h
    }

    private suspend fun captureBitmap(): Bitmap? {
        ensureCapture()
        val reader = imageReader ?: return null

        withContext(Dispatchers.Main) { overlay?.visibility = View.INVISIBLE }
        delay(HIDE_DELAY_MS)
        try {
            val img = reader.acquireLatestImage() ?: return null
            try {
                val plane = img.planes[0]
                val pixelStride = plane.pixelStride
                val rowPadding = plane.rowStride - pixelStride * img.width
                val full = Bitmap.createBitmap(
                    img.width + rowPadding / pixelStride, img.height, Bitmap.Config.ARGB_8888
                )
                full.copyPixelsFromBuffer(plane.buffer)
                if (rowPadding == 0) return full
                val cropped = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
                full.recycle()
                return cropped
            } finally {
                img.close()
            }
        } finally {
            withContext(NonCancellable + Dispatchers.Main) { overlay?.visibility = View.VISIBLE }
        }
    }

    // ---------------------------------------------------------------- notification

    private fun buildNotification(text: String): Notification {
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, TranslatorService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val toggle = PendingIntent.getService(
            this, 2,
            Intent(this, TranslatorService::class.java).setAction(ACTION_TOGGLE),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("مترجم الشاشة")
            .setContentText(text)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_pause),
                    if (paused) "استئناف" else "إيقاف مؤقت",
                    toggle
                ).build()
            )
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "إيقاف",
                    stop
                ).build()
            )
            .build()
    }

    private fun notify(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    // ---------------------------------------------------------------- cleanup

    override fun onDestroy() {
        loopJob?.cancel()
        scope.cancel()
        overlay?.let { runCatching { wm.removeView(it) } }
        overlay = null
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        projection?.stop()
        projection = null
        recognizer.close()
        translator.close()
        super.onDestroy()
    }
}
