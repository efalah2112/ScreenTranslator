package com.ibrahim.screentranslator

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class TranslatorService : Service() {

    companion object {
        const val ACTION_STOP = "com.ibrahim.screentranslator.STOP"
        const val ACTION_TOGGLE = "com.ibrahim.screentranslator.TOGGLE"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"

        private const val CHANNEL = "screen_translator"
        private const val NOTIF_ID = 1
        private const val TAG = "ScreenTranslator"

        /** How long the overlay stays hidden before a screenshot (so OCR sees the original text). */
        const val HIDE_DELAY_MS = 220L

        private val LATIN = Regex("[A-Za-z]{2,}")
        private val ARABIC = Regex("[\\u0600-\\u06FF]")
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private var overlay: OverlayView? = null
    private var bubble: BubbleController? = null
    private var regionView: RegionSelectView? = null

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var capW = 0
    private var capH = 0

    private var loopJob: Job? = null
    @Volatile private var paused = false
    @Volatile private var scanRequested = false
    private var lastSignature = ""
    private val cache = HashMap<String, String>()

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var translator: Translator? = null
    private var translatorKey = ""

    private val bubbleActions = object : BubbleController.Actions {
        override fun isPaused() = paused
        override fun togglePause() = setPaused(!paused)
        override fun scanNow() {
            scanRequested = true
        }
        override fun toggleMode() {
            prefs.auto = !prefs.auto
            this@TranslatorService.notify(statusText())
        }
        override fun selectRegion() = startRegionSelect()
        override fun clearRegion() {
            prefs.setRegion(null)
            lastSignature = ""
            scanRequested = true
            applyStyleNow()
        }
        override fun fontDelta(delta: Float) {
            prefs.fontScale = (prefs.fontScale + delta).coerceIn(0.6f, 1.8f)
            applyStyleNow()
        }
        override fun openSettings() {
            startActivity(
                Intent(this@TranslatorService, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
        override fun stopService() = stopSelf()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = Prefs(this)
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "مترجم الشاشة", NotificationManager.IMPORTANCE_LOW)
        )
    }

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE -> {
                setPaused(!paused)
                return START_NOT_STICKY
            }
        }

        if (projection != null) return START_NOT_STICKY // already running

        val code = intent?.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            intent?.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null || code != Activity.RESULT_OK) {
            stopSelf()
            return START_NOT_STICKY
        }

        // Must be a foreground service BEFORE getting the projection (Android 14+).
        val n = buildNotification("جاري التحضير...")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }

        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                mainHandler.post { stopSelf() }
            }
        }, mainHandler)

        overlay = OverlayView(this).also { wm.addView(it, overlayParams(touchable = false)) }
        bubble = BubbleController(this, wm, prefs, bubbleActions).also { it.show() }
        applyStyleNow()
        loopJob = scope.launch { runLoop() }
        return START_NOT_STICKY
    }

    private fun overlayParams(touchable: Boolean): WindowManager.LayoutParams {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            f,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    // ---------------------------------------------------------------- state helpers (main thread)

    private fun setPaused(p: Boolean) {
        paused = p
        if (p) {
            lastSignature = ""
            overlay?.setItems(emptyList(), 1, 1)
        }
        notify(statusText())
        bubble?.refresh()
    }

    private fun statusText() = when {
        paused -> "متوقف مؤقتاً"
        prefs.auto -> "الترجمة شغالة (تلقائي)"
        else -> "الوضع اليدوي: اضغط ترجم الآن"
    }

    private fun applyStyleNow() {
        overlay?.applyStyle(Accents.colors[prefs.accent], prefs.opacity, prefs.fontScale, prefs.region())
        bubble?.refresh()
    }

    private fun startRegionSelect() {
        if (regionView != null) return
        val v = RegionSelectView(this) { result ->
            regionView?.let { runCatching { wm.removeView(it) } }
            regionView = null
            if (result != null) {
                prefs.setRegion(result)
                lastSignature = ""
                scanRequested = true
            }
            applyStyleNow()
        }
        regionView = v
        wm.addView(v, overlayParams(touchable = true))
    }

    // ---------------------------------------------------------------- main loop

    private suspend fun runLoop() {
        while (currentCoroutineContext().isActive) {
            withContext(Dispatchers.Main) { applyStyleNow() }

            val auto = prefs.auto
            if ((!paused && auto) || scanRequested) {
                scanRequested = false
                try {
                    if (ensureTranslator()) cycle()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.e(TAG, "cycle failed", e)
                }
            }

            // Wait for the next round, but wake up early if "translate now" is tapped.
            val wait = if (auto) prefs.intervalMs else 300L
            var waited = 0L
            while (waited < wait && !scanRequested) {
                delay(100)
                waited += 100
            }
        }
    }

    private suspend fun ensureTranslator(): Boolean {
        val src = Langs.sources[prefs.srcIdx].second
        val tgt = Langs.targets[prefs.tgtIdx].second
        if (src == tgt) {
            notify("لغة المصدر والهدف نفس بعض، غيّرها من الإعدادات")
            return false
        }
        val key = "$src>$tgt"
        if (key != translatorKey) {
            translator?.close()
            translator = null
            val t = Translation.getClient(
                TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(tgt).build()
            )
            notify("جاري تحميل نموذج الترجمة (يحتاج إنترنت أول مرة)...")
            try {
                t.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            } catch (e: Exception) {
                Log.e(TAG, "model download failed", e)
                t.close()
                notify("فشل تحميل النموذج، تأكد من الإنترنت")
                return false
            }
            translator = t
            translatorKey = key
            cache.clear()
            lastSignature = ""
            notify(statusText())
        }
        return true
    }

    private suspend fun cycle() {
        val tr = translator ?: return
        val full = captureBitmap() ?: return
        val fullW = full.width
        val fullH = full.height

        // Optional: only look at the region the user selected.
        var offX = 0
        var offY = 0
        val region = prefs.region()
        val work: Bitmap = if (region != null) {
            val x = (region[0] * fullW).toInt().coerceIn(0, fullW - 1)
            val y = (region[1] * fullH).toInt().coerceIn(0, fullH - 1)
            val w = ((region[2] - region[0]) * fullW).toInt().coerceIn(1, fullW - x)
            val h = ((region[3] - region[1]) * fullH).toInt().coerceIn(1, fullH - y)
            offX = x
            offY = y
            Bitmap.createBitmap(full, x, y, w, h)
        } else {
            full
        }

        try {
            val result = recognizer.process(InputImage.fromBitmap(work, 0)).await()

            val blocks = result.textBlocks.mapNotNull { b ->
                val box = b.boundingBox ?: return@mapNotNull null
                val text = b.text.replace('\n', ' ').trim()
                if (text.length > 400 || !LATIN.containsMatchIn(text) || ARABIC.containsMatchIn(text)) {
                    null
                } else {
                    text to Rect(box).apply { offset(offX, offY) }
                }
            }

            val signature = blocks.joinToString("|") { (t, r) -> "$t@${r.left / 24},${r.top / 24}" }
            if (signature == lastSignature) return
            lastSignature = signature

            if (cache.size > 2000) cache.clear()
            val items = blocks.map { (text, box) ->
                val ar = cache[text] ?: tr.translate(text).await().also { cache[text] = it }
                OverlayView.Item(box, ar)
            }

            withContext(Dispatchers.Main) { overlay?.setItems(items, fullW, fullH) }
        } finally {
            if (work !== full) work.recycle()
            full.recycle()
        }
    }

    // ---------------------------------------------------------------- capture

    @Suppress("DEPRECATION")
    private fun ensureCapture() {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        val w = dm.widthPixels
        val h = dm.heightPixels
        if (virtualDisplay != null && w == capW && h == capH) return

        val oldReader = imageReader
        val newReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        val vd = virtualDisplay
        if (vd == null) {
            // Android 14+: a projection token can create only ONE virtual display, so reuse it afterwards.
            virtualDisplay = projection?.createVirtualDisplay(
                "ScreenTranslator", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                newReader.surface, null, null
            )
        } else {
            vd.resize(w, h, dm.densityDpi)
            vd.surface = newReader.surface
        }
        imageReader = newReader
        oldReader?.close()
        capW = w
        capH = h
    }

    private suspend fun captureBitmap(): Bitmap? {
        ensureCapture()
        val reader = imageReader ?: return null

        withContext(Dispatchers.Main) { overlay?.visibility = View.INVISIBLE }
        delay(HIDE_DELAY_MS)
        try {
            val img = reader.acquireLatestImage() ?: return null
            try {
                val plane = img.planes[0]
                val pixelStride = plane.pixelStride
                val rowPadding = plane.rowStride - pixelStride * img.width
                val full = Bitmap.createBitmap(
                    img.width + rowPadding / pixelStride, img.height, Bitmap.Config.ARGB_8888
                )
                full.copyPixelsFromBuffer(plane.buffer)
                if (rowPadding == 0) return full
                val cropped = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
                full.recycle()
                return cropped
            } finally {
                img.close()
            }
        } finally {
            withContext(NonCancellable + Dispatchers.Main) { overlay?.visibility = View.VISIBLE }
        }
    }

    // ---------------------------------------------------------------- notification

    private fun buildNotification(text: String): Notification {
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, TranslatorService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val toggle = PendingIntent.getService(
            this, 2,
            Intent(this, TranslatorService::class.java).setAction(ACTION_TOGGLE),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("مترجم الشاشة")
            .setContentText(text)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_pause),
                    if (paused) "استئناف" else "إيقاف مؤقت",
                    toggle
                ).build()
            )
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "إيقاف",
                    stop
                ).build()
            )
            .build()
    }

    private fun notify(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    // ---------------------------------------------------------------- cleanup

    override fun onDestroy() {
        loopJob?.cancel()
        scope.cancel()
        bubble?.remove()
        bubble = null
        regionView?.let { runCatching { wm.removeView(it) } }
        regionView = null
        overlay?.let { runCatching { wm.removeView(it) } }
        overlay = null
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        projection?.stop()
        projection = null
        recognizer.close()
        translator?.close()
        translator = null
        super.onDestroy()
    }
}
