package com.ibrahim.screentranslator

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

@Suppress("DEPRECATION")
class MainActivity : Activity() {

    private val reqCapture = 1001
    private val reqNotif = 1002

    private lateinit var prefs: Prefs
    private val d by lazy { resources.displayMetrics.density }
    private fun dp(v: Int) = (v * d).toInt()

    private val accentDots = ArrayList<View>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        window.statusBarColor = 0xFF0F1020.toInt()
        window.navigationBarColor = 0xFF0F1020.toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(28), dp(18), dp(28))
        }

        // ---- header
        root.addView(TextView(this).apply {
            text = "مترجم الشاشة"
            textSize = 30f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "ترجمة فورية فوق أي لعبة أو تطبيق"
            textSize = 14f
            setTextColor(0xFF9AA0D0.toInt())
            setPadding(0, dp(2), 0, dp(18))
        })

        // ---- start card
        val start = card()
        start.addView(title("التشغيل"))
        start.addView(body(
            "1) اسمح بالعرض فوق التطبيقات\n" +
                "2) اضغط ابدأ، وعند سؤال تسجيل الشاشة اختر (الشاشة بالكامل)\n" +
                "3) افتح اللعبة، وبيظهر زر عائم (ع). اضغط عليه للقائمة، أو اسحبه لأي مكان."
        ))
        start.addView(button("① السماح بالعرض فوق التطبيقات", 0xFF3A3F6B.toInt()) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        start.addView(button("② ابدأ الترجمة", Accents.colors[prefs.accent]) { start() })
        start.addView(button("إيقاف", 0xFF5A2A3A.toInt()) {
            startService(Intent(this, TranslatorService::class.java).setAction(TranslatorService.ACTION_STOP))
        })
        root.addView(start)

        // ---- languages
        val lang = card()
        lang.addView(title("اللغات"))
        lang.addView(body("لغة النص في اللعبة"))
        lang.addView(spinner(Langs.sources.map { it.first }, prefs.srcIdx) { prefs.srcIdx = it })
        lang.addView(body("الترجمة إلى"))
        lang.addView(spinner(Langs.targets.map { it.first }, prefs.tgtIdx) { prefs.tgtIdx = it })
        root.addView(lang)

        // ---- mode & speed
        val mode = card()
        mode.addView(title("الوضع والسرعة"))
        mode.addView(Switch(this).apply {
            text = "ترجمة تلقائية (بدون ضغط)"
            setTextColor(Color.WHITE)
            isChecked = prefs.auto
            setOnCheckedChangeListener { _, c -> prefs.auto = c }
            setPadding(0, dp(4), 0, dp(10))
        })
        val intervalLabel = body("")
        mode.addView(intervalLabel)
        mode.addView(seek(
            intervalLabel, 8, ((prefs.intervalMs - 1000) / 500).toInt().coerceIn(0, 8),
            { "سرعة الفحص: كل ${1 + it * 0.5} ثانية" }
        ) { prefs.intervalMs = 1000L + it * 500L })
        root.addView(mode)

        // ---- style
        val style = card()
        style.addView(title("الشكل"))
        style.addView(body("لون التمييز"))
        style.addView(accentRow())
        val opLabel = body("")
        style.addView(opLabel)
        style.addView(seek(opLabel, 70, prefs.opacity - 30, { "شفافية الخلفية: ${it + 30}%" }) {
            prefs.opacity = it + 30
        })
        val fontLabel = body("")
        style.addView(fontLabel)
        style.addView(seek(
            fontLabel, 120, (prefs.fontScale * 100).toInt() - 60,
            { "حجم الخط: ${it + 60}%" }
        ) { prefs.fontScale = (it + 60) / 100f })
        root.addView(style)

        root.addView(TextView(this).apply {
            text = "التغييرات تنطبق مباشرة وهو شغال. من الزر العائم تقدر تحدد منطقة معينة من الشاشة للترجمة، أو تغيّر الوضع."
            textSize = 12f
            setTextColor(0xFF7F86B8.toInt())
        })

        setContentView(ScrollView(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF0F1020.toInt(), 0xFF1B1F3B.toInt())
            )
            addView(root)
        })
    }

    // ------------------------------------------------------------------ UI helpers

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = GradientDrawable().apply {
            setColor(0xFF1E2140.toInt())
            cornerRadius = dp(18).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(0, 0, 0, dp(14)) }
    }

    private fun title(t: String) = TextView(this).apply {
        text = t
        textSize = 17f
        setTextColor(0xFFB9BEFF.toInt())
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, 0, 0, dp(8))
    }

    private fun body(t: String) = TextView(this).apply {
        text = t
        textSize = 14f
        setTextColor(0xFFDDE0FF.toInt())
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun button(text: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        isAllCaps = false
        textSize = 15f
        background = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(14).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(50)
        ).apply { setMargins(0, dp(6), 0, dp(2)) }
        setOnClickListener { onClick() }
    }

    private fun spinner(items: List<String>, selected: Int, onSelect: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        setSelection(selected)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                onSelect(pos)
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun seek(
        label: TextView, max: Int, progress: Int, fmt: (Int) -> String, onChange: (Int) -> Unit
    ): SeekBar {
        label.text = fmt(progress)
        return SeekBar(this).apply {
            this.max = max
            this.progress = progress
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    label.text = fmt(p)
                    if (fromUser) onChange(p)
                }

                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
    }

    private fun accentRow(): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(6), 0, dp(10))
        }
        accentDots.clear()
        Accents.colors.forEachIndexed { i, c ->
            val dot = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(38), dp(38)).apply { setMargins(0, 0, dp(12), 0) }
                setOnClickListener {
                    prefs.accent = i
                    refreshAccentDots()
                }
                tag = c
            }
            accentDots.add(dot)
            row.addView(dot)
        }
        refreshAccentDots()
        return row
    }

    private fun refreshAccentDots() {
        accentDots.forEachIndexed { i, v ->
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(v.tag as Int)
                if (i == prefs.accent) setStroke(dp(3), Color.WHITE)
            }
        }
    }

    // ------------------------------------------------------------------ start flow

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "اسمح بالعرض فوق التطبيقات أولاً", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), reqNotif)
            return
        }
        requestCapture()
    }

    private fun requestCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == reqNotif) requestCapture()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, TranslatorService::class.java)
                .putExtra(TranslatorService.EXTRA_CODE, resultCode)
                .putExtra(TranslatorService.EXTRA_DATA, data)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
