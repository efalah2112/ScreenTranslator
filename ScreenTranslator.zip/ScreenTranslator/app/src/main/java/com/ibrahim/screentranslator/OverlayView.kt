package com.ibrahim.screentranslator

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.View

/** Draws the translation boxes (and the optional region outline) on top of the screen. */
class OverlayView(context: Context) : View(context) {

    data class Item(val box: Rect, val text: String)

    private var items: List<Item> = emptyList()
    private var srcW = 1
    private var srcH = 1
    private val density = resources.displayMetrics.density

    private var accent = 0xFF7C4DFF.toInt()
    private var opacity = 92
    private var fontScale = 1f
    private var region: FloatArray? = null

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * density
    }
    private val regionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
        pathEffect = DashPathEffect(floatArrayOf(14f * density, 8f * density), 0f)
    }
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    fun setItems(list: List<Item>, sourceWidth: Int, sourceHeight: Int) {
        items = list
        srcW = sourceWidth.coerceAtLeast(1)
        srcH = sourceHeight.coerceAtLeast(1)
        invalidate()
    }

    fun applyStyle(accent: Int, opacity: Int, fontScale: Float, region: FloatArray?) {
        val changed = accent != this.accent || opacity != this.opacity ||
            fontScale != this.fontScale || !region.contentEquals(this.region)
        this.accent = accent
        this.opacity = opacity
        this.fontScale = fontScale
        this.region = region
        if (changed) invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val reg = region
        if (items.isEmpty() && reg == null) return

        if (reg != null) {
            regionPaint.color = (accent and 0x00FFFFFF) or 0x99000000.toInt()
            canvas.drawRoundRect(
                RectF(reg[0] * width, reg[1] * height, reg[2] * width, reg[3] * height),
                8f * density, 8f * density, regionPaint
            )
        }

        bg.color = Color.argb((opacity * 255) / 100, 16, 18, 28)
        stroke.color = accent

        val sx = width.toFloat() / srcW
        val sy = height.toFloat() / srcH
        val pad = 5f * density

        for (item in items) {
            val rect = RectF(
                item.box.left * sx - pad,
                item.box.top * sy - pad,
                item.box.right * sx + pad,
                item.box.bottom * sy + pad
            )
            canvas.drawRoundRect(rect, pad * 1.4f, pad * 1.4f, bg)
            canvas.drawRoundRect(rect, pad * 1.4f, pad * 1.4f, stroke)

            val textWidth = (rect.width() - pad * 2).toInt().coerceAtLeast(40)
            val availH = rect.height() - pad * 2

            // Biggest font that fits inside the box (20dp * scale down to 8dp).
            var layout: StaticLayout? = null
            var size = 20f * fontScale * density
            val minSize = 8f * density
            while (size >= minSize) {
                textPaint.textSize = size
                val l = buildLayout(item.text, textWidth)
                layout = l
                if (l.height <= availH) break
                size -= density
            }
            val l = layout ?: continue
            val dy = ((availH - l.height) / 2f).coerceAtLeast(0f)
            canvas.save()
            canvas.translate(rect.left + pad, rect.top + pad + dy)
            l.draw(canvas)
            canvas.restore()
        }
    }

    private fun buildLayout(text: String, width: Int): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, textPaint, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_RTL)
            .setIncludePad(false)
            .build()
}
