package com.ibrahim.screentranslator

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.View

/** Draws the Arabic translation boxes on top of the original English text. */
class OverlayView(context: Context) : View(context) {

    data class Item(val box: Rect, val text: String)

    private var items: List<Item> = emptyList()
    private var srcW = 1
    private var srcH = 1
    private val density = resources.displayMetrics.density

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xEE14161C.toInt()
        style = Paint.Style.FILL
    }
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    fun setItems(list: List<Item>, sourceWidth: Int, sourceHeight: Int) {
        items = list
        srcW = sourceWidth.coerceAtLeast(1)
        srcH = sourceHeight.coerceAtLeast(1)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (items.isEmpty()) return
        val sx = width.toFloat() / srcW
        val sy = height.toFloat() / srcH
        val pad = 5f * density

        for (item in items) {
            val rect = RectF(
                item.box.left * sx - pad,
                item.box.top * sy - pad,
                item.box.right * sx + pad,
                item.box.bottom * sy + pad
            )
            canvas.drawRoundRect(rect, pad, pad, bg)

            val textWidth = (rect.width() - pad * 2).toInt().coerceAtLeast(40)
            val availH = rect.height() - pad * 2

            // Pick the biggest font size (20dp down to 9dp) that fits inside the box.
            var layout: StaticLayout? = null
            var sizeDp = 20
            while (sizeDp >= 9) {
                textPaint.textSize = sizeDp * density
                val l = buildLayout(item.text, textWidth)
                layout = l
                if (l.height <= availH) break
                sizeDp--
            }
            val l = layout ?: continue
            val dy = ((availH - l.height) / 2f).coerceAtLeast(0f)
            canvas.save()
            canvas.translate(rect.left + pad, rect.top + pad + dy)
            l.draw(canvas)
            canvas.restore()
        }
    }

    private fun buildLayout(text: String, width: Int): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, textPaint, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_RTL)
            .setIncludePad(false)
            .build()
}
